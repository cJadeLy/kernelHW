# Adafruit_ImageReader [![Build Status](https://travis-ci.org/adafruit/Adafruit_ImageReader.svg?branch=master)](https://travis-ci.org/adafruit/Adafruit_ImageReader)

Companion library for Adafruit_GFX to load images from SD card.

Requires Adafruit_GFX library and one of the SPI color graphic display libraries, e.g. Adafruit_ILI9341.
